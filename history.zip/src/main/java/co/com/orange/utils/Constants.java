package co.com.orange.utils;

public class Constants {
    private Constants(){}
        public static final String ACTOR = "Usuario";
        public static final String WEB_URL ="environments.default.webdriver.base.url";
        public static final int TIME_SHORT =5;
       
}
